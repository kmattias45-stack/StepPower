# StepPower – enkel version

All kod för appen finns i app.py. Enda paketet som behövs är Streamlit.

Appen är på spanska. Användaren anger antal steg. Ett förenklat antagande är att varje steg ger 3 joules användbar el. Det är ingen uppmätt verkningsgrad eller sensordata.

Energi i joule = antal steg × 3. Energi i kWh = joule / 3 600 000.

Elbesparingen förutsätter att all denna el ersätter el från nätet. Pengar beräknas inte. Exempel: 1 000 steg ger 3 000 J = 0,000833 kWh.

## Kör

Öppna en terminal i denna mapp och kör:

```
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Öppna http://localhost:8501. Stoppa med Ctrl+C.

## Publicera

Ladda upp app.py och requirements.txt till GitHub. I Streamlit Community Cloud väljer du repositoryt och app.py som startfil. .streamlit/config.toml kan följa med för det ljusa temat.

## Ny demo med studentprofiler

Fliken Mi cuenta de demostración visar steg och energi per fiktivt profilnamn. Detta är en demonstrerad inloggningsvy utan lösenord eller riktig autentisering. Använd påhittade namn. Steg matas in manuellt. Data finns bara i webbläsarens Streamlit-session; de är inte en permanent databas och synkas inte mellan enheter. Olika profilnamn i samma session har separata steg.

Rabatten är ett uttryckligt exempel: 7 500 steg ger ett tänkt 2 % avdrag på universitetets månadsavgift. Ingen rabatt är godkänd eller möjlig att lösa in. Universitetet eller sponsorer behöver avtala och finansiera förmånen.

För verklig användning behövs säker inloggning, beständig databas, verifierad identifiering av golvsteg per student och regler för belöningar. En QR-kod kan starta en kopplad gångsession, men löser inte ensam identifieringen av fotsteg i en folkmassa. Mobilens vanliga stegräknare kan inte ensam avgöra vilka steg som togs på golvet.

Appen kan användas i mobilens webbläsare när den publicerats. localhost-adressen på datorn fungerar inte direkt från en annan telefon. Detta är ingen installerad mobilapp.
