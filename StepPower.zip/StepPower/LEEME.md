# StepPower sencillo

Todo el código está en app.py. Solo necesita Streamlit.

Cada paso equivale a 3 joules de electricidad útil en esta simulación. Dividimos los joules entre 3.600.000 para obtener kWh. El ahorro supone que toda esa energía sustituye electricidad de la red. No son mediciones reales ni ahorro de dinero.

## Ejecutar

```
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Perfiles y recompensas de demostración

Mi cuenta de demostración permite entrar con un nombre ficticio y sumar pasos manualmente. No es autenticación real; no hay contraseña ni base de datos. Los datos solo duran durante la sesión de conexión del navegador. No se sincronizan entre dispositivos.

La recompensa inventada es 2 % en la mensualidad universitaria al alcanzar 7.500 pasos. No existe un cupón real ni un acuerdo con la universidad. Una versión real requiere autenticación, almacenamiento permanente, sensores con atribución verificada de pasos, prevención de duplicados y aprobación de las recompensas. Un QR puede vincular una sesión, pero no identifica por sí solo todas las pisadas de varias personas.
